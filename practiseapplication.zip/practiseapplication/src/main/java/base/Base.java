package base;

import java.io.FileInputStream;
import java.io.IOException;
import java.time.Duration;
import java.util.Properties;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.support.ui.WebDriverWait;

public class Base {
	
	public static Properties prop= null;
	public static FileInputStream fis= null;
	public static WebDriver driver;
	public static WebDriverWait wait;

	
	   public Base() {
		   
		   
		   prop = new Properties();
		   try {
			fis= new FileInputStream(System.getProperty("user.dir") + "\\src\\" + "test\\java\\configuration\\config.properties");
			prop.load(fis);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	   }
	   
		public WebDriver intialisation() {

			String browser = prop.getProperty("browser");

			if (browser.equals("chrome")) {

				driver = new ChromeDriver();

			} else if (browser.equals("edge")) {

				driver = new EdgeDriver();
			}

			driver.manage().window().maximize();

			driver.get(prop.getProperty("url"));

			driver.manage().deleteAllCookies();

			driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(25));

			driver.manage().timeouts().pageLoadTimeout(Duration.ofSeconds(25));

			wait = new WebDriverWait(driver, Duration.ofSeconds(20));

			return driver;

		}
	   

}
