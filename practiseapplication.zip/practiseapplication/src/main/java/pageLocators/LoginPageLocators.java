package pageLocators;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import base.Base;

public class LoginPageLocators  extends Base {
	
	    public LoginPageLocators() {
	    	
	    	PageFactory.initElements(driver, this);
	    }

	    
	    @FindBy(name="username")
	    protected WebElement emailid;
	    
	    @FindBy(name="password")
	    protected WebElement password;
	    
	    @FindBy(xpath= "//input[@type='submit' and @value='Log In']")
	    protected WebElement loginBtn;
}
