package pages;

import pageLocators.LoginPageLocators;

public class LoginPage extends LoginPageLocators {
	
	
	public HomePage doLogin(String username, String pass) {
		
		emailid.sendKeys(username);
		password.sendKeys(pass);
		loginBtn.click();
		 return new HomePage();
	}

}
